package snakeandladdergame;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

public class SnakeAndLadderGame {
    
    private static final int BOARD_SIZE = 100;
    private static final Map<Integer, Integer> snakesAndLadders = new HashMap<>();

    static {
        
        snakesAndLadders.put(16, 6);
        snakesAndLadders.put(47, 26);
        snakesAndLadders.put(49, 11);
        snakesAndLadders.put(56, 53);
        snakesAndLadders.put(62, 19);
        snakesAndLadders.put(64, 60);
        snakesAndLadders.put(87, 24);
        snakesAndLadders.put(93, 73);
        snakesAndLadders.put(95, 75);
        snakesAndLadders.put(98, 78);
        
    }

    private int[] playerPositions;

    public SnakeAndLadderGame(int numPlayers) {
        
        playerPositions = new int[numPlayers];
        
    }

    private int rollDice() {
        
        return (int) (Math.random() * 6) + 1;
        
    }

    private int getNextPosition(int currentPosition, int diceValue) {
        
        int newPosition = currentPosition + diceValue;

        if (snakesAndLadders.containsKey(newPosition)) {
            System.out.println("Oops! Snake at position " + newPosition + ". Going down to " + snakesAndLadders.get(newPosition));
            newPosition = snakesAndLadders.get(newPosition);
        } else if (newPosition > BOARD_SIZE) {
            newPosition = 2 * BOARD_SIZE - newPosition - 1;
        }

        return newPosition;
        
    }

    private void playTurn(int playerIndex) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Player " + (playerIndex + 1) + "'s turn. Press Enter to roll the dice.");
        scanner.nextLine();

        int diceValue = rollDice();
        System.out.println("You rolled a " + diceValue);

        int currentPosition = playerPositions[playerIndex];
        int newPosition = getNextPosition(currentPosition, diceValue);
        playerPositions[playerIndex] = newPosition;

        System.out.println("Player " + (playerIndex + 1) + " moved to position " + newPosition);
    
    }

    public void playGame() {
        
        Scanner scanner = new Scanner(System.in);
        int currentPlayer = 0;

        while (true) {
            playTurn(currentPlayer);

            if (playerPositions[currentPlayer] == BOARD_SIZE) {
                System.out.println("Player " + (currentPlayer + 1) + " wins!");
                break;
            }

            currentPlayer = (currentPlayer + 1) % playerPositions.length;

            System.out.println("Press Enter to continue...");
            scanner.nextLine();
        }
        
    }

    public static int minDiceThrows() {
        
        int[] moves = new int[BOARD_SIZE];
        for (int i = 0; i < BOARD_SIZE; i++) {
            moves[i] = -1;
        }

        Queue<Integer> queue = new ArrayDeque<>();
        queue.add(0);
        moves[0] = 0;

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (int i = 1; i <= 6; i++) {
                int next = current + i;

                if (snakesAndLadders.containsKey(next)) {
                    next = snakesAndLadders.get(next);
                }

                if (next >= 0 && next < BOARD_SIZE && moves[next] == -1) {
                    moves[next] = moves[current] + 1;
                    queue.add(next);
                }
            }
        }

        return moves[BOARD_SIZE - 1];
        
    }

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of players:");
        int numPlayers = scanner.nextInt();

        SnakeAndLadderGame game = new SnakeAndLadderGame(numPlayers);
        game.playGame();

        int minMoves = minDiceThrows();
        System.out.println("Minimum number of dice throws to reach the end: " + minMoves);
    
    }
}
